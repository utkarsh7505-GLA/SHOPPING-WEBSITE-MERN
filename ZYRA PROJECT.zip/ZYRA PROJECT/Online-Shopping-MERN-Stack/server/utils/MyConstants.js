const MyConstants = {
  DB_SERVER: 'onlineshopping.7eavwgm.mongodb.net',
  DB_USER: 'tiendung8a6',
  DB_PASS: 'C5QavQodd71CrZ0c',
  DB_DATABASE: 'onlineshopping',
  JWT_SECRET: 'tiendung8a6',
  JWT_EXPIRES: '31556952000', // in milliseconds (01 year = 31556952000 ms)
  EMAIL_USER: 'ngotdung2002@hotmail.com', // gmail service --Microsoft mail service
  EMAIL_PASS: 'ngotiendung123'
};
module.exports = MyConstants;

//mongodb+srv://tiendung8a6:C5QavQodd71CrZ0c@onlineshopping.7eavwgm.mongodb.net/?retryWrites=true&w=majority